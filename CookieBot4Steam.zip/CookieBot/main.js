Game.LoadMod('https://prinzstani.github.io/CookieBot/cookieAutoPlay.js');

