Game.LoadMod('https://prinzstani.github.io/CookieBot/cookieAutoPlayBeta.js');

